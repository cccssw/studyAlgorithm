Study Algorithm

"StudyAlgorithm" is an application that gathered serveral algorithm visualizations in computer science field.Tha main idea to make out this program is to make study and remember complicted algorithms faster and longer.
Hoepe you will enjoy with it.

Requirements
Running under Mac OS X 10.6.x or later.

You can contact with the author Alex Zhao Yu by email:cccssw@gmail.com

Copyright © 2010 Lifame Inc. All rights reserved.